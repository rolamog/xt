--------------------------------------------------
--      ____  ____ _____                        --
--     |    \|  _ )_   _|___ ____   __  __      --
--     | |_  )  _ \ | |/ ·__|  _ \_|  \/  |     --
--     |____/|____/ |_|\____/\_____|_/\/\_|     --
--                                              --
--------------------------------------------------
--                                              --
--       Developers: @rasa7aj & @sbot       --
--     Support: @shahin_X_T,  @093674056 & @Tabrizbot     --
--                                              --
--------------------------------------------------

do

function run(msg, matches)
  return 'rasa7aj Bot V1 Supergroups\nAn advanced Administration ربات ضد اسپم ساخته شده توسط شاهین اکس تی\n\nDevelopers: @Rivaxt @shahin_X_T\nRobot: @music_xt_bot @shahin_X_T @Serx666\nChannels: @androidxt @shahin_X_T\n\nCheckout: https://github.com/rasa7aj/sbot\nGNU GPL v2 license.'
end

return {
  patterns = {
    "^#version$"
  }, 
  run = run 
}

end
